<?php
	$lang["media"] = "Media";
	$lang["media_sub"] = "Media manage";
	$lang["media_manager"] = "Files Manager";
	$lang["media_add_folder"] = "Add Directory";
	$lang["media_rename_folder"] = "Rename Directory";
	$lang["media_folder_found"] = "Directory not found";
	$lang["media_remove_folder"] = "Remove Directory";
	$lang["media_upload_file"] = "Upload File";
	$lang["media_remove_file"] = "Remove File";
	$lang["media_remove_file_msg"] = "You can't remove file. Please try again.";
	$lang["media_file_found"] = "File not found.";
	$lang["media_file_rename"] = "Sorry, system can't change file name. Please try again.";
	$lang["media_view"] = "View";
	$lang["media_insert"] = "Insert";
	$lang["media_exists"] = "Folder name exists. Please try again.";
?>