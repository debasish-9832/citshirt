<?php
	$lang["most_article_admin_setting_title_validate"] = "Title must be at least 2 to 200 characters.";
	$lang["most_article_admin_setting_content_validate"] = "Content is required";
	$lang["most_article_admin_setting_add_error_msg"] = "Cannot add most article html";
	$lang["most_article_admin_setting_edit_error_msg"] = "Cannot edit most article html";
	$lang["most_article_admin_setting_edit_not_found_error_msg"] = "Most article html not found";
	$lang["most_article_admin_setting_show_title"] = "Show title";
	$lang["most_article_admin_setting_count_article_title"] = "Number of Article";
	$lang["most_article_admin_setting_show_thumb"] = "Show thumbnail";
	$lang["most_article_admin_setting_class_sfx"] = "Class Sfx";
	$lang["lastest_article_admin_setting_show_date"] = "Show date";
	$lang["most_article_admin_setting_show_intro_text"] = "Show intro text";
	
	$lang["most_article_list_element_title"] = "Click to choose element or add new";
	$lang["most_article_list_module_name_title"] = "Most article Title";
	$lang["most_article_list_key_title"] = "Key";
	$lang["most_article_list_id_title"] = "ID";
	$lang["most_article_list_option_title"] = "Option";
?>