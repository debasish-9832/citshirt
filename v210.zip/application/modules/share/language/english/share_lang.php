<?php
	$lang["share_admin_setting_title_validate"] = "Title must be at least 2 to 200 characters.";
	$lang["share_admin_setting_content_validate"] = "Content is required";
	$lang["share_admin_setting_add_error_msg"] = "Cannot add share html";
	$lang["share_admin_setting_edit_error_msg"] = "Cannot edit share html";
	$lang["share_admin_setting_edit_not_found_error_msg"] = "share html not found";
	$lang["share_admin_setting_option_title"] = "Option";
	$lang["share_admin_setting_publish_title"] = "Publish";
	$lang["share_admin_setting_facebook_title"] = "URL to share facebook";
	$lang["share_admin_setting_link_place"] = "URL";
	$lang["share_admin_setting_option_box_count"] = "Box Count";
	$lang["share_admin_setting_option_button_count"] = "Button Count";
	$lang["share_admin_setting_option_button"] = "Button";
	$lang["share_admin_setting_option_icon_link"] = "Icon Link";
	$lang["share_admin_setting_option_icon"] = "Icon";
	$lang["share_admin_setting_option_link"] = "Link";
	$lang["share_admin_setting_google_title"] = "URL to share google+";
	$lang["share_admin_setting_option_none"] = "None";
	$lang["share_admin_setting_option_inline"] = "Inline";
	$lang["share_admin_setting_option_bubble"] = "Bubble";
	$lang["share_admin_setting_vertical_bubble"] = "Vertical Bubble";
	$lang["share_admin_setting_tweet_title"] = "URL to share tweet";
	$lang["share_admin_setting_option_count"] = "Count";
	$lang["share_admin_setting_option_above_count"] = "Above the button";
	$lang["share_admin_setting_option_beside_count"] = "Beside the button";
	$lang["share_admin_setting_vetical_count"] = "Vetical";
	$lang["share_admin_setting_horizontal_count"] = "Horizontal";
	$lang["share_admin_setting_pinterest_title"] = "URL to share pinterest";
	$lang["share_admin_setting_linkedin_title"] = "URL to share linkedin";
	$lang["share_admin_setting_url_help"] = "If does not exist url to share social. You will share current page.";
	
	$lang["share_list_element_title"] = "Click to choose element or add new";
	$lang["share_list_module_name_title"] = "share Title";
	$lang["share_list_key_title"] = "Key";
	$lang["share_list_id_title"] = "ID";
	$lang["share_list_option_title"] = "Option";
?>