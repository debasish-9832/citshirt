<?php
	$lang["login_admin_setting_title_validate"] = "Title must be at least 2 to 200 characters.";
	$lang["login_admin_setting_content_validate"] = "Content is required";
	$lang["login_admin_setting_add_error_msg"] = "Cannot add login html";
	$lang["login_admin_setting_edit_error_msg"] = "Cannot edit login html";
	$lang["login_admin_setting_edit_not_found_error_msg"] = "login html not found";
	
	$lang["login_list_element_title"] = "Click to choose element or add new";
	$lang["login_list_module_name_title"] = "Login Title";
	$lang["login_list_key_title"] = "Key";
	$lang["login_list_id_title"] = "ID";
	$lang["login_list_option_title"] = "Option";
?>