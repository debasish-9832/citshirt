<?php
	$lang["menu_admin_setting_title_validate"] = "Title must be at least 2 to 200 characters.";
	$lang["menu_admin_setting_content_validate"] = "Content is required";
	$lang["menu_admin_setting_add_error_msg"] = "Cannot add menu html";
	$lang["menu_admin_setting_edit_error_msg"] = "Cannot edit menu html";
	$lang["menu_admin_setting_edit_not_found_error_msg"] = "Menu html not found";
	$lang["menu_admin_setting_class_sfx_title"] = "Class Sfx";
	$lang["menu_admin_setting_nav_style_title"] = "Menu Style";
	$lang["menu_admin_setting_nav_white_title"] = "White";
	$lang["menu_admin_setting_nav_default_title"] = "Default";
	$lang["menu_admin_setting_nav_display_title"] = "Menu Display";
	$lang["menu_admin_setting_nav_fixed_top_title"] = "Fixed To Top";
	$lang["menu_admin_setting_nav_fixed_bottom_title"] = "Fixed To Bottom";
	$lang["menu_admin_setting_nav_static_top_title"] = "Static Top";
	$lang["menu_admin_setting_nav_inverse_title"] = "Inverse";
	
	$lang["menu_list_element_title"] = "Click to choose element or add new";
	$lang["menu_list_module_name_title"] = "Menu Title";
	$lang["menu_list_key_title"] = "Key";
	$lang["menu_list_id_title"] = "ID";
	$lang["menu_list_option_title"] = "Option";
?>