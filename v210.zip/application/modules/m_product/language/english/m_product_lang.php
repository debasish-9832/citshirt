<?php
	$lang["m_product_admin_setting_title_validate"] = "Title must be at least 2 to 200 characters.";
	$lang["m_product_admin_setting_content_validate"] = "Content is required";
	$lang["m_product_admin_setting_add_error_msg"] = "Cannot add m_product html";
	$lang["m_product_admin_setting_edit_error_msg"] = "Cannot edit m_product html";
	$lang["m_product_admin_setting_edit_not_found_error_msg"] = "m_product html not found";
	$lang["m_product_admin_setting_layout_title"] = "Products Layout";
	$lang["m_product_admin_setting_count_product_title"] = "Number of products";
	$lang["m_product_admin_setting_show_product_title"] = "Show Products";
	$lang["m_product_admin_setting_lastest_title"] = "Lastest Products";
	$lang["m_product_admin_setting_future_title"] = "Future Products";
	$lang["m_product_admin_setting_sale_title"] = "Sale Products";
	$lang["m_product_admin_setting_show_title"] = "Show Title";
	$lang["m_product_admin_setting_count_cols_title"] = "Default number of product in a row";
	$lang["m_product_admin_setting_class_sfx_title"] = "Class Sfx";
	
	$lang["m_product_list_element_title"] = "Click to choose element or add new";
	$lang["m_product_list_module_name_title"] = "m_product Title";
	$lang["m_product_list_key_title"] = "Key";
	$lang["m_product_list_id_title"] = "ID";
	$lang["m_product_list_option_title"] = "Option";
?>