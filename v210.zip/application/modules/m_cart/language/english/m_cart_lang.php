<?php
	$lang["m_cart_admin_setting_title_validate"] = "Title must be at least 2 to 200 characters.";
	$lang["m_cart_admin_setting_content_validate"] = "Content is required";
	$lang["m_cart_admin_setting_add_error_msg"] = "Cannot add cart html";
	$lang["m_cart_admin_setting_edit_error_msg"] = "Cannot edit cart html";
	$lang["m_cart_admin_setting_edit_not_found_error_msg"] = "Cart html not found";
	$lang["m_cart_admin_setting_border_color_title"] = "Border Color";
	$lang["m_cart_admin_setting_text_color_title"] = "Text Color";
	$lang["m_cart_admin_setting_box_shadow_title"] = "Box Shadow";
	
	$lang["m_cart_list_element_title"] = "Click to choose element or add new";
	$lang["m_cart_list_module_name_title"] = "Cart Title";
	$lang["m_cart_list_key_title"] = "Key";
	$lang["m_cart_list_id_title"] = "ID";
	$lang["m_cart_list_option_title"] = "Option";
?>