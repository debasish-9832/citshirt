<?php
	$lang["breadcrumbs_admin_setting_title_validate"] = "Title must be at least 2 to 200 characters.";
	$lang["breadcrumbs_admin_setting_content_validate"] = "Content is required";
	$lang["breadcrumbs_admin_setting_add_error_msg"] = "Cannot add breadcrumbs html";
	$lang["breadcrumbs_admin_setting_edit_error_msg"] = "Cannot edit breadcrumbs html";
	$lang["breadcrumbs_admin_setting_edit_not_found_error_msg"] = "breadcrumbs html not found";
	$lang["breadcrumbs_admin_setting_show_home_icon_title"] = "Show home icon";
	$lang["breadcrumbs_admin_setting_choose_layout_title"] = "Choose layout";
	$lang["breadcrumb_default"] = "Default";
	$lang["breadcrumbs_arrows"] = "Arrows";
	$lang["breadcrumbs_admin_setting_class_sfx_title"] = "Class Sfx";
	
	$lang["breadcrumbs_list_element_title"] = "Click to choose element or add new";
	$lang["breadcrumbs_list_module_name_title"] = "breadcrumbs Title";
	$lang["breadcrumbs_list_key_title"] = "Key";
	$lang["breadcrumbs_list_id_title"] = "ID";
	$lang["breadcrumbs_list_option_title"] = "Option";
?>