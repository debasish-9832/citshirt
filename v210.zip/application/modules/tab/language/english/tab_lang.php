<?php
	$lang["tab_admin_setting_title_validate"] = "Title must be at least 2 to 200 characters.";
	$lang["tab_admin_setting_theme_title"] = "Tab Theme";
	$lang["tab_admin_setting_add_icon_title"] = "Add Icon";
	$lang["tab_admin_setting_name_title"] = "Tab Name";
	$lang["tab_admin_setting_color_blue_title"] = "Blue";
	$lang["tab_admin_setting_color_bricky_title"] = "Bricky";
	$lang["tab_admin_setting_color_green_title"] = "Green";
	$lang["tab_admin_setting_color_yellow_title"] = "Yellow";
	$lang["tab_admin_setting_add_title"] = "Add";
	
	$lang["tab_list_element_title"] = "Click to choose element or add new";
	$lang["tab_list_module_name_title"] = "Tab Title";
	$lang["tab_list_key_title"] = "Key";
	$lang["tab_list_id_title"] = "ID";
	$lang["tab_list_option_title"] = "Option";
?>