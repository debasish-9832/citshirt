<?php
	$lang["categories_admin_setting_title_validate"] = "Title must be at least 2 to 200 characters.";
	$lang["categories_admin_setting_content_validate"] = "Content is required";
	$lang["categories_admin_setting_add_error_msg"] = "Cannot add categories html";
	$lang["categories_admin_setting_edit_error_msg"] = "Cannot edit categories html";
	$lang["categories_admin_setting_edit_not_found_error_msg"] = "Categories html not found";
	$lang["categories_admin_setting_categories_title"] = "Parent Category";
	$lang["categories_admin_setting_layout_title"] = "Display Categories";
	$lang["categories_admin_setting_list_title"] = "List Categories";
	$lang["categories_admin_setting_thumb_title"] = "Thumbnail Categories";
	$lang["categories_admin_setting_categories_title"] = "Categories";
	$lang["categories_admin_setting_class_sfx_title"] = "Class Sfx";
	$lang["categories_admin_setting_show_title_title"] = "Show Title";
	$lang["categories_admin_setting_show_level_title"] = "Show Category Level";
	$lang["categories_admin_setting_level_1"] = "Level 1";
	$lang["categories_admin_setting_show_all"] = "Show All";
	$lang["categories_admin_setting_show_number_title"] = "Show number category";
	
	$lang["categories_list_element_title"] = "Click to choose element or add new";
	$lang["categories_list_module_name_title"] = "categories Title";
	$lang["categories_list_key_title"] = "Key";
	$lang["categories_list_id_title"] = "ID";
	$lang["categories_list_option_title"] = "Option";
?>